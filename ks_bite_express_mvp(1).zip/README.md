# K’S Bite Express — starter MVP

This is a source-code starter for the K’S Bite Express pre-order website.

## Included
- Public mobile-friendly ordering page (no student account required)
- Sandwiches, bread choice, sauce choices, quantities and notes
- Cash payment at pickup
- Admin login using Supabase Auth
- Admin order list and status changes
- Pause/resume online order intake
- Supabase SQL schema and environment template

## Important limitations
- This is a starter MVP, not a deployed or production-certified service.
- Students receive an order number after submission. Student-side live tracking and push/SMS notifications are not implemented.
- Pickup times are selectable in 15-minute increments from 11:30 to 21:30; the app does not yet validate past times.
- Test with sample orders before sharing the public link.

## Setup
1. Install Node.js (LTS) on a computer.
2. Extract this ZIP.
3. In the project folder run `npm install`.
4. In Supabase, open SQL Editor and run `supabase/schema.sql`.
   If you already ran the schema for this project, do not needlessly rerun it.
5. Create your admin account in Supabase Authentication > Users.
6. Grant admin role using the SQL snippet at the bottom of `supabase/schema.sql`, replacing `YOUR_EMAIL`.
7. Copy `.env.example` to `.env`.
8. Add your Supabase Project URL and Publishable key:
   - `VITE_SUPABASE_URL=...`
   - `VITE_SUPABASE_ANON_KEY=...`
   Never use a `service_role` or Secret key in the browser app.
9. Run `npm run dev` to test locally.
10. Run `npm run build` to create the deployable `dist` folder. Deploy the project using a static host such as Vercel or Netlify, and add the same two environment variables in the host's project settings.

## Admin
Open the deployed website and add `#admin` to the end of its URL, for example:
`https://your-site.example/#admin`

## Menu
- Sandwich Special — 150 DA
- Sandwich Escalope Marinée — 220 DA
- Sandwich Kebda — 300 DA
- Sandwich Merguez — 300 DA
- Sandwich Frite Omelette — 120 DA
- Sandwich Frite Fromage — 120 DA

Breads: Boulanger, Panini, Matlou3
Sauces: Mayonnaise, Ketchup, Harissa, Sauce Maison
Opening hours: 11:30–21:30
